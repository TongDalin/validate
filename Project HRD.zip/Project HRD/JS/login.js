// var form = document.getElementById('frm');
// form.addEventListener('submit', function (e) {
//     e.preventDefault()
//     let username=document.getElementById('defaultLoginFormEmail').value;
//     let password=document.getElementById('defaultLoginFormPassword').value;
//     let btn = document.getElementById('btn').value;
//     //let p=new RegExp('e','gi')

//     let patt = /[^a-z]/gi;
//     let pattschool = /[^a-z \s]/gi;
//     let msgResult = document.getElementById('userEmail');
//     let scmsgResult = document.getElementById('userPass');
//     if (username == "" || username == null) {
//         msgResult.innerHTML = "E-mail Cannot be blank"
//         msgResult.style.color = "purple"
//     }
//     if (password == "" || password == null) {
//         scmsgResult.innerHTML = "Password cannot be blank"
//         scmsgResult.style.color = 'blue'
//     }
// })\

var attempt = 3; // Variable to count number of attempts.
// Below function Executes on click of login button.
function validate(){
var username = document.getElementById("defaultLoginFormEmail").value;
var password = document.getElementById("defaultLoginFormPassword").value;
if ( username == "Ter" && password == "123"){
// alert ("Login successfully");
window.location = "index.html"; // Redirecting to other page.
return false;
}
else{
attempt --;// Decrementing by one.
alert("You are Input incorrect"+ attempt +" time;");
// Disabling fields after 3 attempts.
if( attempt == 0){
document.getElementById("defaultLoginFormEmail").disabled = true;
document.getElementById("defaultLoginFormPassword").disabled = true;
document.getElementById("btn").disabled = true;
return false;
}
}
}
